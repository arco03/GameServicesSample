//-----------------------------------------------------------------------
// <copyright file="TypeInclusionFilter.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;

namespace Sirenix.OdinInspector
{
	/// <summary> Specifies the types to include based on certain criteria. </summary>
	[Flags]
	public enum TypeInclusionFilter
	{
		None = 0,

		/// <summary> Represents types that are not interfaces, abstracts, or generics. </summary>
		IncludeConcreteTypes = 1 << 0,

		IncludeGenerics = 1 << 1,

		IncludeAbstracts = 1 << 2,

		IncludeInterfaces = 1 << 3,

		IncludeAll = IncludeConcreteTypes | IncludeGenerics | IncludeAbstracts | IncludeInterfaces,
	}
}
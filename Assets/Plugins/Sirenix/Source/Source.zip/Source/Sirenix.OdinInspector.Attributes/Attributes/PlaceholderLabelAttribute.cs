//-----------------------------------------------------------------------
// <copyright file="PlaceholderLabelAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector
{
    //using System;

    //[AttributeUsage(AttributeTargets.All, AllowMultiple = true, Inherited = true)]
    //[System.Diagnostics.Conditional("UNITY_EDITOR")]
    //public class PlaceholderLabelAttribute : Attribute
    //{
    //    public SdfIconType Icon;
    //    public string LabelText;

    //    public PlaceholderLabelAttribute()
    //    {
    //    }

    //    public PlaceholderLabelAttribute(string labelText)
    //    {
    //        this.LabelText = labelText;
    //    }
    //    public PlaceholderLabelAttribute(string labelText, SdfIconType icon)
    //    {
    //        this.LabelText = labelText;
    //        this.Icon = icon;
    //    }
    //}
}
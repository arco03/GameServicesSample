//-----------------------------------------------------------------------
// <copyright file="TypeDrawerSettingsAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;

namespace Sirenix.OdinInspector
{
	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class TypeDrawerSettingsAttribute : Attribute
	{
		/// <summary>
		/// Specifies whether a base type should be used instead of all types.
		/// </summary>
		public Type BaseType = null;

		/// <summary>
		/// Filters the result.
		/// </summary>
		public TypeInclusionFilter Filter = TypeInclusionFilter.IncludeAll;
	}
}